package com.jpmc.gti.automation.performance;

import com.jpmc.gti.automation.performance.request.CreateTransactionItemRequest;
import com.jpmc.gti.automation.performance.request.ReadTransactionItemRequest;
import com.jpmc.gti.automation.performance.request.UpdateTransactionItemRequest;
import com.jpmc.gti.automation.performance.response.CreateTransactionItemResponse;
import com.jpmc.gti.automation.performance.response.ReadTransactionItemResponse;
import com.jpmc.gti.automation.performance.response.UpdateTransactionItemResponse;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;

import org.apache.log4j.Logger;

@WebService
public class IBrokerPerformanceService 
{
  private static final Logger logger = Logger.getLogger(IBrokerPerformanceService.class);
	

  @WebMethod
  @WebResult(name="readTransactionItemResponse")
  public ReadTransactionItemResponse readTransaction(@WebParam(name="readTransactionItemRequest")ReadTransactionItemRequest request)
  {
	logger.debug("Starting readTransaction()");
	ReadTransactionItemResponse response = new ReadTransactionItemResponse();
	response.setRequest(request);
	
	logger.debug("Done readTransaction()");
	return response;
  }

  @WebMethod
  @WebResult(name="updateTransactionItemResponse")
  public UpdateTransactionItemResponse updateTransaction(@WebParam(name="updateTransactionItemRequest")UpdateTransactionItemRequest request)
  {
	logger.debug("Starting updateTransaction()");
	UpdateTransactionItemResponse response = new UpdateTransactionItemResponse();
	response.setRequest(request);

	logger.info("updateTransaction[recordID=" + request.getRecordID() +
							",transactionStatus=" + request.getTransactionStatus() +
							",messageText=" + request.getMessageText() +
							"]");

	logger.debug("Done updateTransaction()");
	return response;
  }
  
  @WebMethod
  @WebResult(name="pingResponse")
  public String ping()
  {
	return "Service is up and running";
  }
  
}
