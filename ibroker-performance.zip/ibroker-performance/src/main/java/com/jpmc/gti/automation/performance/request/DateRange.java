package com.jpmc.gti.automation.performance.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="dateRange")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="dateRange", propOrder={ 
		"from",
		"to"})
public class DateRange 
{
  @XmlElement(name="from")
  private String from;
  
  @XmlElement(name="to")
  private String to;

  public String getFrom() {
	return from;
  }

  public void setFrom(String from) {
	this.from = from;
  }

  public String getTo() {
	return to;
  }

  public void setTo(String to) {
	this.to = to;
  }

  
}
