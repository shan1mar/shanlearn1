package com.jpmc.gti.automation.performance.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="status")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="status", propOrder={
		"reasonCode",
		"reasonDescription"})
public class Status 
{
  @XmlElement(name="reasonCode")  
  private String reasonCode;
  @XmlElement(name="reasonDescription")  
  private String reasonDescription;
  
  public String getReasonCode() {
	return reasonCode;
  }
  
  public void setReasonCode(String reasonCode) {
	this.reasonCode = reasonCode;
  }
  
  public String getReasonDescription() {
	return reasonDescription;
  }
  
  public void setReasonDescription(String reasonDescription) {
	this.reasonDescription = reasonDescription;
  }
  
  public boolean isFailed()
  {
	return ("Failure".equalsIgnoreCase(reasonCode));
  }
}
