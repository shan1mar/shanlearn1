package com.jpmc.gti.automation.performance.response;

import com.jpmc.gti.automation.performance.request.UpdateTransactionItemRequest;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement(name="updateTransactionItemResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="updateTransactionItemResponse", propOrder={
		"status"})
public class UpdateTransactionItemResponse 
{
  @XmlElement(name="status")
  private Status status;
 
  @XmlTransient
  private UpdateTransactionItemRequest request;
  
  public Status getStatus() {
	return status;
  }
  
  public void setStatus(Status status) {
	this.status = status;
  }

  public UpdateTransactionItemRequest getRequest() {
	return request;
  }

  public void setRequest(UpdateTransactionItemRequest request) {
	this.request = request;
  }
  
  
}
