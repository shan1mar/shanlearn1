package com.jpmc.gti.automation.performance.response;

import com.jpmc.gti.automation.performance.request.ReadTransactionItemRequest;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement(name="readTransactionItemResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="readTransactionItemResponse", propOrder={
		"responses",
		"status"})
public class ReadTransactionItemResponse
{
  @XmlElement(name="transactionItemResponse")
  private List<TransactionItemResponse> responses;
  
  @XmlElement(name="status")  
  private Status status;
  
  @XmlTransient
  private ReadTransactionItemRequest request;
  
  public List<TransactionItemResponse> getResponses() {
	return responses;
  }

  public void setResponses(List<TransactionItemResponse> responses) {
	this.responses = responses;
  }

  public Status getStatus() {
	return status;
  }
	  
  public void setStatus(Status status) {
	this.status = status;
  }

  public ReadTransactionItemRequest getRequest() {
	return request;
  }

  public void setRequest(ReadTransactionItemRequest request) {
	this.request = request;
  }
}
