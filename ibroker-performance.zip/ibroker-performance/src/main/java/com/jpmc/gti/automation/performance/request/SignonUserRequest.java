package com.jpmc.gti.automation.performance.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="signonUserRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="signonUserRequest", propOrder={ 
		"userID",
		"password"})
public class SignonUserRequest 
{
  @XmlElement(name="userID", required=true)
  private String userID;

  @XmlElement(name="password", required=true)
  private String password;

  public String getUserID() {
	return userID;
  }

  public void setUserID(String userID) {
	this.userID = userID;
  }

  public String getPassword() {
	return password;
  }

  public void setPassword(String password) {
	this.password = password;
  }
}
