package com.jpmc.gti.automation.performance.transformer;

import java.util.ArrayList;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

import com.jpmc.gti.automation.performance.response.ReadTransactionItemResponse;
import com.jpmc.gti.automation.performance.response.TransactionItemResponse;

public class FilterTransactions extends AbstractMessageTransformer {

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding)
			throws TransformerException {

		ReadTransactionItemResponse resp = (ReadTransactionItemResponse) message.getPayload();
		String status = "COMPLETE";
		ArrayList<TransactionItemResponse> filtered = new ArrayList<TransactionItemResponse>();
		for(TransactionItemResponse obj: resp.getResponses()) {
			if(obj.getTransactionStatus().equals(status)) {
				filtered.add(obj);
			}
		}

		return filtered;
	}
}
