package com.jpmc.gti.automation.performance;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="transactionItem")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="transactionItem", propOrder={
		"source", 
		"messageText", 
		"userID",
		"transactionStatus",
		"correlationID"})
public class TransactionItem 
{
  @XmlElement(name="source", required=true)  
  private String source;

  @XmlElement(name="messageText", required=true)  
  private String messageText;
  
  @XmlElement(name="userID")  
  private String userID;

  @XmlElement(name="correlationID")  
  private String correlationID;

  @XmlElement(name="transactionStatus")  
  private String transactionStatus;

  public String getSource() {
	return source;
  }

  public void setSource(String source) {
	this.source = source;
  }

  public String getMessageText() {
	return messageText;
  }

  public void setMessageText(String messageText) {
	this.messageText = messageText;
  }

  public String getUserID() {
	return userID;
  }

  public void setUserID(String userID) {
	this.userID = userID;
  }

  public String getCorrelationID() {
	return correlationID;
  }

  public void setCorrelationID(String correlationID) {
	this.correlationID = correlationID;
  }

  public String getTransactionStatus() {
	return transactionStatus;
  }

  public void setTransactionStatus(String transactionStatus) {
	this.transactionStatus = transactionStatus;
  }

public byte[] getBlob()
  {
	return messageText.getBytes();
  }
}
