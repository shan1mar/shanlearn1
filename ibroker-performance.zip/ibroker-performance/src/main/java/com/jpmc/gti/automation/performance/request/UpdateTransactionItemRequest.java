package com.jpmc.gti.automation.performance.request;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="updateTransactionItemRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="updateTransactionItemRequest", propOrder={
		"recordID",
		"transactionStatus",
		"messageText"})
public class UpdateTransactionItemRequest
{
  @XmlElement(name="recordID", required=true)  
  private String recordID;

  @XmlElement(name="transactionStatus", required=true)  
  private String transactionStatus;
  
  @XmlElement(name="messageText")  
  private String messageText;

  public String getRecordID() {
	return recordID;
  }

  public void setRecordID(String recordID) {
	this.recordID = recordID;
  }
  
  public String getTransactionStatus() {
	return transactionStatus;
  }

  public void setTransactionStatus(String transactionStatus) {
	this.transactionStatus = transactionStatus;
  }

  public String getMessageText() {
	return messageText;
  }

  public void setMessageText(String messageText) {
	this.messageText = messageText;
  }
}
