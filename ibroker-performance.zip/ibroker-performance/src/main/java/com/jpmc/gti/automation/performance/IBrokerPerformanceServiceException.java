package com.jpmc.gti.automation.performance;

import com.jpmc.gti.automation.performance.response.CreateTransactionItemResponse;
import com.jpmc.gti.automation.performance.response.Status;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;

public class IBrokerPerformanceServiceException extends AbstractTransformer
{
  @Override
  protected CreateTransactionItemResponse doTransform(Object src, String enc)
	throws TransformerException 
  {
	CreateTransactionItemResponse response = new CreateTransactionItemResponse();		
	Status status = new Status();
		
	response.setStatus(status);
	status.setReasonCode("Failure");
	status.setReasonDescription(((Exception)src).toString());

	return response;
  }
	

}
