package com.jpmc.gti.automation.performance.transformer;

import org.apache.log4j.Logger;
import org.mule.api.MuleMessage;
import org.mule.transport.jdbc.JdbcConnector;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.util.ArrayList;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

import java.text.SimpleDateFormat;
import java.sql.Timestamp;
import java.util.Date;

import com.jpmc.gti.automation.performance.request.DateRange;
import com.jpmc.gti.automation.performance.request.ReadTransactionItemRequest;
import com.jpmc.gti.automation.performance.response.Status;
import com.jpmc.gti.automation.performance.response.ReadTransactionItemResponse;
import com.jpmc.gti.automation.performance.response.TransactionItemResponse;


public class ReadTransactionItemQueryMessageTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(ReadTransactionItemQueryMessageTransformer.class);
  private static final String SUCCESS = "Success";
  private static final String FAILURE = "Failure";
  
  @Override
  public ReadTransactionItemResponse transformMessage(
	  					MuleMessage message, String outputEncoding)
	throws TransformerException 
  {
	Connection connection = null;
	CallableStatement callableStatement = null;
	ResultSet resultSet = null;	
	long recordID = 0;
	
	logger.debug("Starting transformMessage()");

	//validate request
	ReadTransactionItemResponse response = (ReadTransactionItemResponse)message.getPayload();
	ReadTransactionItemRequest request = response.getRequest();
	DateRange dateRange = request.getDateRange();
	
	if (isNull(request.getRecordID()) && isNull(request.getSource())
			&& isNull(request.getCorrelationID()) 
			&& (dateRange==null || (isNull(dateRange.getFrom()) && isNull(dateRange.getTo()))) )
	{		
	  setErrorMessage(response, FAILURE, "Not a valid parameter value(s).");
	  return response;
	}
	
	if (dateRange == null)
	{
	  dateRange = new DateRange();	
	}
	
	ArrayList<TransactionItemResponse> transactionItems = new ArrayList<TransactionItemResponse>();	
	JdbcConnector connector = (JdbcConnector) muleContext.getRegistry().lookupConnector("IBrokerReadDatabase");
	String query = (String)muleContext.getRegistry().lookupObject("readTransaction");		

	try
	{
	  logger.info("getting connection");
	  connection = connector.getConnection();
	  callableStatement = connection.prepareCall(query);
	  callableStatement.registerOutParameter(1, oracle.jdbc.driver.OracleTypes.CURSOR);	  
	  callableStatement.setString(2, request.getRecordID());
	  callableStatement.setString(3, request.getSource());
	  callableStatement.setString(4, dateRange.getFrom());
	  callableStatement.setString(5, dateRange.getTo());
	  callableStatement.setString(6, request.getCorrelationID());
	  
	  logger.info("running query");
	  callableStatement.executeQuery();
	
	  logger.info("reading resultyset");
	  resultSet = (ResultSet)callableStatement.getObject(1);		
	  while(resultSet.next())
	  {
		TransactionItemResponse transactionItem = new TransactionItemResponse();
		recordID = resultSet.getLong("record_id"); 
		transactionItem.setRecordID(String.valueOf(recordID));
		transactionItem.setSource(resultSet.getString("source_name"));
		transactionItem.setUserID(resultSet.getString("user_id"));
		transactionItem.setCorrelationID(resultSet.getString("correlation_id"));

		Timestamp value = resultSet.getTimestamp("time_stamp");
		logger.info("Timestamp stamp stamp=" + value);
		
		Date dt = new Date(value.getTime());
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ"); //ISO 8601 date format
		String xmlDate = df.format(dt);	
		logger.info("XML date=" + xmlDate);	
		
		String strResult = xmlDate.substring(0, xmlDate.length()-2) + ":" + xmlDate.substring(xmlDate.length()-2);
		
		transactionItem.setTimeStamp(strResult);
		logger.info("ISO8601 date=" + strResult);	
		
		transactionItem.setMessageText(resultSet.getString("message"));
		transactionItem.setTransactionStatus(resultSet.getString("status"));
		
		
		transactionItems.add(transactionItem);
	  }
	  logger.info("done reading result");
	  response.setResponses(transactionItems);
	  setStatus(response);
	}
	catch(Exception e)
	{
	  String errorMessage = "An error occurred while calling store procedure, " + query;
	  setErrorMessage(response, FAILURE, errorMessage);
	  logger.error(errorMessage, e);
	  
	  //throw new RuntimeException(e);
	}
	finally
	{
	  //Close resources
	  try{
	    if (resultSet != null) resultSet.close();	  
		if (callableStatement != null) callableStatement.close();		
		if (connection != null) connection.close();		
	  } catch(Exception e){
		//ignore  
	  }
	}
	
	logger.info("Done transformMessage()");
	return response;
  }

  private void setStatus(ReadTransactionItemResponse response)
  {
	Status status = new Status();
	if (response.getResponses() != null && response.getResponses().size() > 0)
	{
	  status.setReasonCode(SUCCESS);
	  status.setReasonDescription("Retrived transaction item successfully!");
	}
	else
	{
	  status.setReasonCode(FAILURE);
	  status.setReasonDescription("There are no transaction item found!");		
	}
	
	response.setStatus(status);
  }

  private void setErrorMessage(ReadTransactionItemResponse response, String reasonCode, String reasonDescription)
  {
	Status status = new Status();
	status.setReasonCode(reasonCode);
	status.setReasonDescription(reasonDescription);
	
	response.setStatus(status);
  }
  
  private boolean isNull(String value)
  {
	return (value == null || "".equals(value));
  }
  
}
