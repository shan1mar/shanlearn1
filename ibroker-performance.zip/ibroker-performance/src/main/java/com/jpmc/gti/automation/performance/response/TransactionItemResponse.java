package com.jpmc.gti.automation.performance.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.jpmc.gti.automation.performance.TransactionItem;

@XmlRootElement(name="transactionItemResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="transactionItemResponse", propOrder={
		"recordID",
		"timeStamp"})
public class TransactionItemResponse extends TransactionItem 
{
  @XmlElement(name="recordID", required=true)  
  private String recordID;

  @XmlElement(name="timeStamp", required=true)  
  private String timeStamp;

  public String getRecordID() {
	return recordID;
  }
	  
  public void setRecordID(String recordID) {
	this.recordID = recordID;
  }

  public String getTimeStamp() {
	return timeStamp;
  }

  public void setTimeStamp(String timeStamp) {
	this.timeStamp = timeStamp;
  }  
}
