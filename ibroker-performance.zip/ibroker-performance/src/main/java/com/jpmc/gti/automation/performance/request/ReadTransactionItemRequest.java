package com.jpmc.gti.automation.performance.request;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="readTransactionItemRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="readTransactionItemRequest", propOrder={ 
		"recordID",
		"source",
		"dateRange",
		"correlationID"})
public class ReadTransactionItemRequest 
{
  @XmlElement(name="recordID")
  private String recordID;
	
  @XmlElement(name="source", required=true)  
  private String source;
  
  @XmlElement(name="dateRange")  
  private DateRange dateRange;

  @XmlElement(name="correlationID")  
  private String correlationID;
  
  
  public String getSource() {
	return source;
  }

  public void setSource(String source) {
	this.source = source;
  }

  public String getRecordID() {
		return recordID;
  }

  public void setRecordID(String recordID) {
		this.recordID = recordID;
  }
  
  public DateRange getDateRange() {
	return dateRange;
  }

  public void setDateRange(DateRange dateRange) {
	this.dateRange = dateRange;
  }

  public String getCorrelationID() {
	return correlationID;
  }

  public void setCorrelationID(String correlationID) {
	this.correlationID = correlationID;
  }
  
}
