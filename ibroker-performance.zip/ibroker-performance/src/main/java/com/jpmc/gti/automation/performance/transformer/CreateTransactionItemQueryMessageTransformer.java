package com.jpmc.gti.automation.performance.transformer;

import org.apache.log4j.Logger;
import org.mule.api.MuleMessage;
import org.mule.transport.jdbc.JdbcConnector;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Connection;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

import com.jpmc.gti.automation.performance.request.CreateTransactionItemRequest;
import com.jpmc.gti.automation.performance.response.Status;
import com.jpmc.gti.automation.performance.response.CreateTransactionItemResponse;

public class CreateTransactionItemQueryMessageTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(CreateTransactionItemQueryMessageTransformer.class);
  private static final String SUCCESS = "Success";
  private static final String FAILURE = "Failure";
  
  @Override
  public CreateTransactionItemResponse transformMessage(
	  					MuleMessage message, String outputEncoding)
	throws TransformerException 
  {
	Connection connection = null;
	CallableStatement callableStatement = null;
	ResultSet resultSet = null;
	long recordID = 0;
	
	logger.debug("Starting transformMessage()");
	
	
	CreateTransactionItemResponse response = (CreateTransactionItemResponse)message.getPayload();
	CreateTransactionItemRequest request = response.getRequest();
	if (isNull(request.getSource()) || isNull(request.getMessageText()))
	{
	  setErrorMessage(response, FAILURE, "Not a valid parameter value(s).");
	  return response;
	}
	
	JdbcConnector connector = (JdbcConnector) muleContext.getRegistry().lookupConnector("IBrokerDatabase");
	String query = (String)muleContext.getRegistry().lookupObject("createTransaction");		
		
	try
	{
	  connection = connector.getConnection();
	  callableStatement = connection.prepareCall(query);
	  callableStatement.registerOutParameter(1, oracle.jdbc.driver.OracleTypes.CURSOR);
	  callableStatement.setString(2, request.getSource());
	  callableStatement.setString(3, request.getMessageText());
	  callableStatement.setString(4, request.getUserID());
	  callableStatement.setString(5, request.getCorrelationID());
	  callableStatement.setString(6, request.getTransactionStatus());
	  callableStatement.executeQuery();
	
	  resultSet = (ResultSet)callableStatement.getObject(1);		
	  if(resultSet.next())
	  {
		  recordID = resultSet.getLong("record_id");
	  }
	  
	  response.setRecordID(String.valueOf(recordID));
	  setStatus(response);
	}
	catch(Exception e)
	{
	  String errorMessage = "An error occurred while calling store procedure, " + query;
	  setErrorMessage(response, FAILURE, errorMessage);
	  logger.error(errorMessage, e);
	  
	  //throw new RuntimeException(e);
	}
	finally
	{
	  //Close resources
	  try{
	    if (resultSet != null) resultSet.close();	  
		if (callableStatement != null) callableStatement.close();		
		if (connection != null) connection.close();		
	  } catch(Exception e){
		//ignore  
	  }
	}
	
	logger.debug("Done transformMessage()");
	return response;
  }

  private void setStatus(CreateTransactionItemResponse response)
  {
	Status status = new Status();
	status.setReasonCode(SUCCESS);
	status.setReasonDescription("Created a transaction item successfully!");

	response.setStatus(status);
  }
  
  private void setErrorMessage(CreateTransactionItemResponse response, String reasonCode, String reasonDescription)
  {
	Status status = new Status();
	status.setReasonCode(reasonCode);
	status.setReasonDescription(reasonDescription);
	
	response.setStatus(status);
  }
  
  private boolean isNull(String value)
  {
	return (value == null || "".equals(value));
  }

  
  
}
