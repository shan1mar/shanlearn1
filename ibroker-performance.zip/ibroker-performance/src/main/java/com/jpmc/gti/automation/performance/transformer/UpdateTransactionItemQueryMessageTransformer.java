package com.jpmc.gti.automation.performance.transformer;

import org.apache.log4j.Logger;
import org.mule.api.MuleMessage;
import org.mule.transport.jdbc.JdbcConnector;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Connection;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

import com.jpmc.gti.automation.performance.request.UpdateTransactionItemRequest;
import com.jpmc.gti.automation.performance.response.Status;
import com.jpmc.gti.automation.performance.response.UpdateTransactionItemResponse;

public class UpdateTransactionItemQueryMessageTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(UpdateTransactionItemQueryMessageTransformer.class);
  private static final String SUCCESS = "Success";
  private static final String FAILURE = "Failure";
  
  @Override
  public UpdateTransactionItemResponse transformMessage(
	  					MuleMessage message, String outputEncoding)
	throws TransformerException 
  {
	Connection connection = null;
	CallableStatement callableStatement = null;
	ResultSet resultSet = null;
	
	logger.debug("Starting transformMessage()");	
	
	UpdateTransactionItemResponse response = (UpdateTransactionItemResponse)message.getPayload();
	UpdateTransactionItemRequest request = response.getRequest();
	if (isNull(request.getTransactionStatus()) || isNull(request.getRecordID()))
	{
	  setErrorMessage(response, FAILURE, "Not a valid parameter value(s).");
	  return response;
	}
	
	JdbcConnector connector = (JdbcConnector) muleContext.getRegistry().lookupConnector("IBrokerDatabase");
	String query = (String)muleContext.getRegistry().lookupObject("updateTransaction");		
		
	try
	{
	  connection = connector.getConnection();
	  callableStatement = connection.prepareCall(query);
	  callableStatement.setString(1, request.getRecordID());
	  callableStatement.setString(2, request.getTransactionStatus());
	  callableStatement.setString(3, request.getMessageText());
	  callableStatement.executeQuery();
	
	  setStatus(response);
	}
	catch(Exception e)
	{
	  String errorMessage = "An error occurred while calling store procedure, " + query;
	  setErrorMessage(response, FAILURE, errorMessage);
	  logger.error(errorMessage, e);
	  
	  //throw new RuntimeException(e);
	}
	finally
	{
	  //Close resources
	  try{
	    if (resultSet != null) resultSet.close();	  
		if (callableStatement != null) callableStatement.close();		
		if (connection != null) connection.close();		
	  } catch(Exception e){
		//ignore  
	  }
	}
	
	logger.debug("Done transformMessage()");
	return response;
  }

  private void setStatus(UpdateTransactionItemResponse response)
  {
	Status status = new Status();
	status.setReasonCode(SUCCESS);
	status.setReasonDescription("Updated a transaction item successfully!");

	response.setStatus(status);
  }
  
  private void setErrorMessage(UpdateTransactionItemResponse response, String reasonCode, String reasonDescription)
  {
	Status status = new Status();
	status.setReasonCode(reasonCode);
	status.setReasonDescription(reasonDescription);
	
	response.setStatus(status);
  }
  
  private boolean isNull(String value)
  {
	return (value == null || "".equals(value));
  }

  
  
}
