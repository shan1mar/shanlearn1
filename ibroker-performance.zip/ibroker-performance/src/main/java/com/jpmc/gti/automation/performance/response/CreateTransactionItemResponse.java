package com.jpmc.gti.automation.performance.response;

import com.jpmc.gti.automation.performance.request.CreateTransactionItemRequest;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement(name="createTransactionItemResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="createTransactionItemResponse", propOrder={
		"recordID",
		"status"})
public class CreateTransactionItemResponse 
{
  @XmlElement(name="recordID")  
  private String recordID;
  
  @XmlElement(name="status")
  private Status status;
 
  @XmlTransient
  private CreateTransactionItemRequest request;
  
  public String getRecordID() {
	return recordID;
  }
  
  public void setRecordID(String recordID) {
	this.recordID = recordID;
  }

  public Status getStatus() {
	return status;
  }
  
  public void setStatus(Status status) {
	this.status = status;
  }

  public CreateTransactionItemRequest getRequest() {
	return request;
  }

  public void setRequest(CreateTransactionItemRequest request) {
	this.request = request;
  }
  
  
}
